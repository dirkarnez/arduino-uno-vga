/*****************************************************************************
    System Name : NTSC Trial
    File Name   : defSYS.h
    Content     : 
    Version     : 0.0
    CPU board   : Arduino UNO
    Compiler    : Arduino 1.0.4
    History     : 2013/05/xx
*****************************************************************************/
/*----------------------------------------------------------------------------
;  Copyleft @Nabe_RMC
;---------------------------------------------------------------------------*/
/*==========================================================================*/
/*  Includes                                                                */
/*==========================================================================*/
#define CSL_INCLUDE
#include "defSYS.h"
#include "defCSL.h"
#include "defINT.h"

/*==========================================================================*/
/*                                                                          */
/*==========================================================================*/
PROGMEM const UB CCSL::cg_code[ (0x7F - 0x20 +1)*8 ] = { 
#include "CG_NTSC.h"
};

/*==========================================================================*/
/*  Program                                                                 */
/*==========================================================================*/
CCSL::CCSL()
{
    Ini();
}

void CCSL::Ini()
{
    clear_screen();
}


/*  ----------------------------------------------------
    -   Clear Screen                                    -
    -----------------------------------------------------   */
void CCSL::clear_screen()
{
    int i;
    for( i = 0; i < FL_COL_MAX*ROW_MAX; i++ ){
        vram_data[i] = 0x20;
    }
    SetVram();
}


/*  ----------------------------------------------------
    -   Set Cursor                                     -
    -----------------------------------------------------   */
UB CCSL::set_cursor( UB x, UB y)
{
    if( (x>=FL_COL_MAX)||(y>=ROW_MAX) ){
        return( EOF );
    }
	else{
		cursor_x = x;
		cursor_y = y;
	}
}


/*  ----------------------------------------------------
    -   Put_Char with posion argument                   -
    -----------------------------------------------------   */

UB CCSL::put_char( UB c )
{
	UB i;
	
	if( c==0x0D ){				/* 0x0D : CR	*/
		cursor_x = 0;
	}
	else if( c==0x0A ){			/* 0x0A : NL	*/
		if( cursor_y < 13 ){	/* not line end	*/
			cursor_x = 0;
			cursor_y++;
		}
		else{					/* end line		*/
			for( i=0 ; i< FL_COL_MAX*(ROW_MAX-1) ; i++ ){
				vram_data[i] = vram_data[i+FL_COL_MAX];
			}
		}
	}
	else{
		if( (cursor_x == (FL_COL_MAX-1)) && (cursor_y==(ROW_MAX-1)) ){
			for( i=0; i< (FL_COL_MAX*ROW_MAX-1); i++ ){
				vram_data[i] = vram_data[i+1];
			}
			vram_data[FL_COL_MAX*ROW_MAX-1] = c;
		}
		else{
			vram_data[FL_COL_MAX*cursor_y + cursor_x] = c;
			cursor_x++;
			if(cursor_x >= FL_COL_MAX ){
				cursor_x = 0;
				cursor_y++;
				if(cursor_y >=ROW_MAX){
					cursor_y = ROW_MAX-1;
				}
			}
		}
	}

	SetVram();
	
	return(c);
}


/*  ----------------------------------------------------
    -   Put_Char with posion argument                   -
    -----------------------------------------------------   */
UB CCSL::put_char( UB x, UB y, UB c )
{
    UH line,column,row;
    UH row_top,line_top;
    UH data_row_top;
    UH tmp1,tmp2,tmp3;
    UH offset;
    
    if( (c > 0x7F)||(c < 0x20)||(x >=FL_COL_MAX)||(y >= ROW_MAX) ){
        return( EOF );
    }
    else{
        vram_data[FL_COL_MAX*y+x] = c;
        offset = FL_COL_MAX*y+x;
        data_row_top = y * FL_COL_MAX;
        row_top = y * COL_MAX * 7;
        for( line = 0; line < 7; line++ ){
            line_top = line * COL_MAX + row_top;
            if( (offset %2)==0 ){
                tmp1 = data_row_top + x;
                tmp2 = (vram_data[tmp1]-0x20);
                tmp3 = tmp2*8+line;
                vram_line[line_top + x/2] = pgm_read_byte( &cg_code[tmp3] );
            }
            else{
                tmp1 = data_row_top + x;
                tmp2 = (vram_data[tmp1]-0x20);
                tmp3 = tmp2*8+line;
                vram_line_ODD[line_top + (x-1)/2] = pgm_read_byte( &cg_code[tmp3] );
            }
        }
        return( 0 );
    }
}

/*  ----------------------------------------------------
    -   Print                                           -
    -----------------------------------------------------   */
void CCSL::print(const char *str)
{
	while(*str){
		put_char(*str++);
	}
}


/*  ----------------------------------------------------
    -   set font code to V-RAM                          -
    -----------------------------------------------------   */
void CCSL::SetVram()
{
    UH line,column,row;
    UH row_top,line_top;
    UH data_row_top;
    UH tmp1,tmp2,tmp3;
    
#if (FL_COLUMN ==1)
    
    for( row = 0; row < ROW_MAX; row++ ){
        data_row_top = row * FL_COL_MAX;
        row_top = row * COL_MAX * 7;
        for( line = 0; line < 7; line++ ){                      /* scanline */
            line_top = line * COL_MAX + row_top;
            for( column = 0; column < COL_MAX; column++ ){      /* column   */
                tmp1 = data_row_top+column*2;
                tmp2 = (vram_data[tmp1]-0x20);
                tmp3 = tmp2*8+line;
                vram_line[line_top + column] = pgm_read_byte( &cg_code[tmp3] );
            }
        }
    }

    for( row = 0; row < ROW_MAX; row++ ){
        data_row_top = row * FL_COL_MAX;
        row_top = row * COL_MAX * 7;
        for( line = 0; line < 7; line++ ){                      /* scanline */
            line_top = line * COL_MAX + row_top;
            for( column = 0; column < COL_MAX; column++ ){      /* column   */
                tmp1 = data_row_top+column*2+1;
                tmp2 = (vram_data[tmp1]-0x20);
                tmp3 = tmp2*8+line;
                vram_line_ODD[line_top + column] = pgm_read_byte( &cg_code[tmp3] );
            }
        }
    }
    
    
#else
    
    for( row = 0; row < ROW_MAX; row++ ){
        data_row_top = row * COL_MAX;
        row_top = row * COL_MAX * 7;
        for( line = 0; line < 7; line++ ){                      /* scanline */
            line_top = line * COL_MAX + row_top;
            for( column = 0; column < COL_MAX; column++ ){      /* column   */
                tmp1 = data_row_top+column;
                tmp2 = (vram_data[tmp1]-0x20);
                tmp3 = tmp2*8+line;
                vram_line[line_top + column] 
                = pgm_read_byte( &cg_code[tmp3] );
            }
        }
    }
    
#endif
    
}


/*  ----------------------------------------------------
    -   Set_Line_Color                                  -
    -----------------------------------------------------   */
UB CCSL::set_line_color( UB line, UB color, UB odd_even )
{
    if( (line >= ROW_MAX)||(color >=8) ){
        return( EOF );
    }
    else if( odd_even %2 ){
        UB_ColorN_ODD[line] = color;
    }
    else{
        UB_ColorN[line] = color;
    }
    return( 0 );
    
}




