/*****************************************************************************
    System Name : NTSC Trial
    File Name   : defINT.h
    Content     : 
    Version     : 0.0
    CPU board   : Arduino UNO
    Compiler    : Arduino 1.0.4
    History     : 2013/05/xx
*****************************************************************************/
/*----------------------------------------------------------------------------
;  Copyleft @Nabe_RMC
;---------------------------------------------------------------------------*/
#ifdef      INT_INCLUDE
#define     INT_EXT 
#else
#define     INT_EXT extern
#endif

/*==========================================================================*/
/*  Includes                                                                */
/*==========================================================================*/
#ifndef     COMMON_H
#include    "nabe_common.h"
#endif

/*==========================================================================*/
/*  DEFINE                                                                  */
/*==========================================================================*/
#define FL_COLUMN   1
#define FL_COL_MAX  ( COL_MAX *2 )
#define COL_MAX     ( 8 )           /* number of characters per line        */
#define ROW_MAX     ( 10 )          /* display number of lines available    */
#define LINE_MAX    ( 16 )

#if (FL_COLUMN==1)
#define TXT_SIZE    ( FL_COL_MAX * ROW_MAX )
#else
#define TXT_SIZE    ( COL_MAX * ROW_MAX )
#endif

#define FRM_OFF         ( 0 )   /* only H-Sync                              */
#define FRM_ON          ( 1 )   /* Display Frame line                       */
#define FRM_VSYNC       ( 2 )   /* V-Sync line                              */

#define V_SYNC_START    ( 4 )
#define V_SYNC_END      ( 7 )
#define V_BLANK         ( 20 )
#define V_FRM_TOP       ( 60 )
#define V_TXT_END       ( 60 + LINE_MAX * ROW_MAX )
#define V_FRM_END       ( 220 )
#define H_LINE_END      ( 262 )

/*==========================================================================*/
/*                                                                          */
/*==========================================================================*/
INT_EXT UB  vram_data[TXT_SIZE];
INT_EXT UB  vram_line[ROW_MAX*COL_MAX*7];
INT_EXT UH  UH_AddrData_n;
INT_EXT UB  UB_ColorN[ROW_MAX]; 

#if (FL_COLUMN==1)
INT_EXT UB  vram_line_ODD[ROW_MAX*COL_MAX*7];
INT_EXT UH  UH_AddrData_n_ODD;
INT_EXT UB  UB_ColorN_ODD[ROW_MAX];
#endif

INT_EXT UB  LineColor[ROW_MAX];
INT_EXT UH UH_AddrDataTop;
INT_EXT UH UH_AddrDataNow;
INT_EXT UH UH_AddrDataNow_ODD;
INT_EXT UB UB_ModePLS;
INT_EXT UB UB_ModePTN;
INT_EXT UB UB_ModePTN_BF;
INT_EXT UB UB_Color;
INT_EXT UB UB_cg_line;


class CINT
{
public:
    CINT();                         /* constructor for initializing         */
    
    void Ini();
    void ExecFunc(UB);
    void FitDelay(UB);
    void JobAsy();
    UB  Check132ms();
    void Int_TestPattern();
    void Int_Disp1();
    void Int_Disp2();
    void Int_Disp3();
    void Int_Disp4();
    void Int_Disp5();
    void Int_Disp6();
    void Int_Disp7();
    void Int_Txt();
    void Int_Txt_ODD();
    void Int_TestP();
    void SP_TestPattern(UB);
    void SP_Pattern1(UB);
    void SP_Pattern2(UB);
    void SP_Pattern3(UB);
    void SP_Pattern4(UB);
    void SP_Pattern5(UB);
    void SP_Pattern6(UB);
    void SP_Pattern7(UB);
    void SP_Txt( UH, UB, UB );
    void SP_Txt_ODD( UH, UB, UB );
    
private:
    UH  UH_TCNT1;
    UH  UH_hline;
    UB  UB_hline;
    UB  UB_hline_ovf;
    UB  UB_scanline;
    UB  UB_row;
    static UB UBf_132ms_req;

};


