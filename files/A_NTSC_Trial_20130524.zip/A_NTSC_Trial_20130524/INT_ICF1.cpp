/*****************************************************************************
    System Name : NTSC Trial
    File Name   : INT_ICF1.cpp
    Content     : 
    Version     : 0.0
    CPU board   : Arduino UNO
    Compiler    : Arduino 1.0.4
    History     : 2013/05/xx
*****************************************************************************/
/*----------------------------------------------------------------------------
;  Copyleft @Nabe_RMC
;---------------------------------------------------------------------------*/
/*==========================================================================*/
/*  Includes                                                                */
/*==========================================================================*/
#include "defSYS.h"
#include "defCRT.h"
#include "defINT.h"
#include "defCSL.h"

/*==========================================================================*/
/*  Program                                                                 */
/*==========================================================================*/
/*  ----------------------------------------------------
    -   function pointer                                -
    ----------------------------------------------------*/
void ( CINT::*TBL_int_icf1[] )(void) = {
    &CINT::Int_Txt,                 /*  0                                   */
    &CINT::Int_Txt_ODD,             /*  1                                   */
    &CINT::Int_Disp1,               /*  2                                   */
    &CINT::Int_Disp2,               /*  3                                   */
    &CINT::Int_Disp3,               /*  4                                   */
    &CINT::Int_Disp4,               /*  5                                   */
    &CINT::Int_Disp5,               /*  6                                   */
    &CINT::Int_Disp6,               /*  7                                   */
    &CINT::Int_Disp7,               /*  8                                   */
    &CINT::Int_TestPattern,         /*  9                                   */
};

void CINT::ExecFunc( UB nIndex )
{
    (this->*TBL_int_icf1[nIndex])();
};


/*----------------------------------------------------------------------------
    interrupt ICF1
*---------------------------------------------------------------------------*/
CINT    objINT;

ISR (TIMER1_CAPT_vect)
{
    PORTC = 7;                      /* 0IRE data    need at V-sync          */
    objINT.FitDelay( TCNT1L );      /* 割り込み遅延ばらつきの合わせ込み     */
                    /* Compensation of the variration in delay of interrupt */

    objINT.ExecFunc( UB_ModePTN );
}


/*  ----------------------------------------------------
    -   index:2 Display 1                               -
    -----------------------------------------------------   */
void CINT::Int_Disp1( void )
{
    SP_Pattern1( UB_ModePLS );
    Int_TestP();
}

/*  ----------------------------------------------------
    -   index:3 Display 2                               -
    -----------------------------------------------------   */
void CINT::Int_Disp2( void )
{
    SP_Pattern2( UB_ModePLS );
    Int_TestP();
}


/*  ----------------------------------------------------
    -   index:4 Display3                                -
    -----------------------------------------------------   */
void CINT::Int_Disp3( void )
{
    SP_Pattern3( UB_ModePLS );
    Int_TestP();
}

/*  ----------------------------------------------------
    -   index:5 Display4                                -
    -----------------------------------------------------   */
void CINT::Int_Disp4( void )
{
    SP_Pattern4( UB_ModePLS );
    Int_TestP();
}

/*  ----------------------------------------------------
    -   index:6 Display5                                -
    -----------------------------------------------------   */
void CINT::Int_Disp5( void )
{
    SP_Pattern5( UB_ModePLS );
    Int_TestP();
}

/*  ----------------------------------------------------
    -   index:7 Display6                                -
    -----------------------------------------------------   */
void CINT::Int_Disp6( void )
{
    SP_Pattern6( UB_ModePLS );
    Int_TestP();
}

/*  ----------------------------------------------------
    -   index:8 Display7                                -
    -----------------------------------------------------   */
void CINT::Int_Disp7( void )
{
    SP_Pattern7( UB_ModePLS );
    Int_TestP();
}

/*  ----------------------------------------------------
    -   index:9 Test pattern                           -
    ---------------------------------------------------     */
void CINT::Int_TestPattern( void )
{
    SP_TestPattern( UB_ModePLS );
    Int_TestP();
}   


/*  -----------------------------------------------------
    -   Common for Display 1-7 & Test pattrn             -
    -----------------------------------------------------   */
void CINT::Int_TestP( void )
{
    UH_hline++;
    if( UH_hline == V_SYNC_END ){       /* end of timing of V-sync pulse    */
        OCR1A = CRT_OCR1A_HS;
        UB_ModePLS = FRM_OFF;
        P_DBG1_OFF;
    }       
    else if( UH_hline == V_FRM_TOP ){
        UB_ModePLS = FRM_ON;
    }
    else if( UH_hline == V_FRM_END ){
        UB_ModePLS = FRM_OFF;
    }
    else if( UH_hline == H_LINE_END ){
        UB_ModePLS = FRM_OFF;
        UH_hline = 0;
        UB_scanline = 0;
        JobAsy();
        UB_ModePTN = UB_ModePTN_BF;
    }
    else if( UH_hline == V_SYNC_START ){    /* start of timing of V-sync    */
        OCR1A  = CRT_OCR1A_VS;
        TCCR1A = CRT_TCCR1A;
        UB_ModePLS = FRM_VSYNC;
        P_DBG1_ON;
        UH_AddrDataNow = UH_AddrData_n;
        UH_AddrDataNow_ODD = UH_AddrData_n_ODD;
        UB_row = 0;
    }
}


/*  ----------------------------------------------------
    -   index:0 Text Even column                        -
    -----------------------------------------------------   */
void CINT::Int_Txt( void )
{
    SP_Txt( (UH)(UH_AddrDataNow), UB_ModePLS, UB_Color );

    UH_hline++;
    if( UH_hline == V_SYNC_END ){       /* end of timing of V-sync pulse    */
        OCR1A = CRT_OCR1A_HS;           
        UB_ModePLS = FRM_OFF;
        P_DBG1_OFF;
    }       
    else if( (UH_hline >= V_FRM_TOP) && (UH_hline < V_FRM_END) ){
        if( UH_hline < V_TXT_END ){
            UB_cg_line = (UB_scanline %16); /* 0 - 15                       */
            if( UB_cg_line < 7 ){
                UH_AddrDataNow += COL_MAX;
                UB_ModePLS = FRM_ON;
            }
            else if(UB_cg_line == 9 ){
                UB_Color = UB_ColorN[UB_row];
                UB_row++;
                UB_ModePLS = FRM_OFF;
            }
            else{
                UB_ModePLS = FRM_OFF;
            }           
        UB_scanline++;
        }
        else{
            UB_ModePLS = FRM_OFF;
        }
    }
    else if( UH_hline == H_LINE_END ){
        UB_ModePLS = FRM_OFF;
        UH_hline = 0;
        UB_scanline = 0;
        JobAsy();
        if( UB_ModePTN_BF >=2 ){
            UB_ModePTN = UB_ModePTN_BF;
        }
        else{
            UB_ModePTN = 1;
        }
    }
    else if( UH_hline == V_SYNC_START ){     /* start of timing of V-sync   */
        OCR1A  = CRT_OCR1A_VS;
        TCCR1A = CRT_TCCR1A;
        UB_ModePLS = FRM_VSYNC;
        P_DBG1_ON;
        UH_AddrDataNow = UH_AddrData_n;
        UH_AddrDataNow_ODD = UH_AddrData_n_ODD;
        UB_row = 0;
    }
}


/*  ----------------------------------------------------
    -   index:1 Text Odd column                        -
    -----------------------------------------------------   */
void CINT::Int_Txt_ODD( void )
{
    SP_Txt_ODD( (UH)(UH_AddrDataNow_ODD), UB_ModePLS, UB_Color );

    UH_hline++;
    if( UH_hline == V_SYNC_END ){       /* end of timing of V-sync pulse    */
        OCR1A = CRT_OCR1A_HS;
        UB_ModePLS = FRM_OFF;
        P_DBG1_OFF;
    }       
    else if( (UH_hline >= V_FRM_TOP) && (UH_hline < V_FRM_END) ){
        if( UH_hline < V_TXT_END ){
            UB_cg_line = (UB_scanline %16); /* 0 - 15                       */
            if( UB_cg_line < 7 ){
                UH_AddrDataNow_ODD += COL_MAX;
                UB_ModePLS = FRM_ON;
            }
            else if(UB_cg_line == 9 ){
                UB_Color = UB_ColorN_ODD[UB_row];
                UB_row++;
                UB_ModePLS = FRM_OFF;
            }
            else{
                UB_ModePLS = FRM_OFF;
            }           
        UB_scanline++;
        }
        else{
            UB_ModePLS = FRM_OFF;
        }
    }
    else if( UH_hline == H_LINE_END ){
        UB_ModePLS = FRM_OFF;
        UH_hline = 0;
        UB_scanline = 0;
        JobAsy();
        UB_ModePTN = 0;
    }
    else if( UH_hline == V_SYNC_START ){    /* start of timing of V-sync    */
        OCR1A  = CRT_OCR1A_VS;
        TCCR1A = CRT_TCCR1A;
        UB_ModePLS = FRM_VSYNC;
        P_DBG1_ON;
        UH_AddrDataNow = UH_AddrData_n;
        UH_AddrDataNow_ODD = UH_AddrData_n_ODD;
        UB_row = 0;
    }
}


/*  ----------------------------------------------------
    -   for fixed interval job                          -
    -----------------------------------------------------   */
void CINT::JobAsy()
{
    static UB   UBCT_33ms = 0;
    
    UBCT_33ms++;
    
    if( ( UBCT_33ms %4 ) == 0 ){
        UBf_132ms_req = 1;
    }

}

