/*****************************************************************************
    System Name : Simple Analog RGB 2011
    File Name   : INTdef.h
    Content     : 
    Version     : 0.0
    CPU board   : Arduino Duemilanove
    Compiler    : 
    History     :2011/10/23
*****************************************************************************/
/*----------------------------------------------------------------------------
;  Copyleft Nabe_RMC
;---------------------------------------------------------------------------*/
#ifdef      INT_INCLUDE
#define     INT_EXT 
#else
#define     INT_EXT extern
#endif

/*==========================================================================*/
/*  Includes                                                                */
/*==========================================================================*/
#ifndef     COMMON_H
#include    "nabe_common.h"
#endif

/*==========================================================================*/
/*  DEFINE                                                                  */
/*==========================================================================*/
#define	N_BAP10A	96*64/8			/* 96 * 64 pixel						*/

/*==========================================================================*/
/*                                                                          */
/*==========================================================================*/
INT_EXT UH UH_AddrDataTop;
INT_EXT UB UB_ModeCRT;
INT_EXT UB f_CRT;
INT_EXT UB f_req_data_trans;
INT_EXT	UB f_TrgChangeColor1;
INT_EXT	UB f_TrgChangeColor2;
INT_EXT	UB f_TrgChangeColor3;
INT_EXT UB f_disp_on;
INT_EXT UB f_SYS_200ms_req;
INT_EXT UB f_SYS_500ms_req;
INT_EXT UB f_SYS_1sec_req;

class CINT
{
public:
    CINT();                         /* constructor for initializing         */
    
    void Ini();
    void JobAsy();
    void ExecFunc(UB);

    void Int_ICF1_RGB_TEST();
    void Int_ICF1_RGB_NUCO();
    void Int_ICF1_Reserve();
    void FitDelay( UB );
	
	void OutData_64( UH );
	void OutData_70( UH );
    void OutTxt( UH, UB );
	void OutTxtRGB_1( UH, UB, UB );	/* 96画素								*/
	void OutTxtRGB_2( UH, UB, UB );	/* 96画素	PortData自動インクリメント	*/
	void OutTxtCRT_1( UH, UB, UB );

    UH  UH_AddrDataNow;

    PROGMEM static const UB MASK_bit[ 8 ];
    
private:
    UH  UH_TCNT1;
    UH  UH_hline;
    UB  UB_scanline;            /* 0 - 9    水平走査ライン  文字行数×10    */
    UB  UB_char_row;            /* 0 - 9    文字行          10行            */
    UB  UB_cg_line;             /* 0 - 9    キャラジェネ選択ライン          */

};


