/*****************************************************************************
    System Name : Simple Analog RGB 2011
    File Name   : CRTdef.h
    Content     : 
    Version     : 0.0
    CPU board   : Arduino Duemilanove
    Compiler    : 
    History     :2011/10/21
*****************************************************************************/
/*----------------------------------------------------------------------------
;  Copyleft Nabe_RMC
;---------------------------------------------------------------------------*/
#ifdef      CRT_INCLUDE
#define     CRT_EXT 
#else
#define     CRT_EXT extern
#endif

/*==========================================================================*/
/*  Includes                                                                */
/*==========================================================================*/
#ifndef     COMMON_H
#include    "nabe_common.h"
#endif

/*==========================================================================*/
/*  DEFINE                                                                  */
/*==========================================================================*/
#define CRT_TEST1  0
#define CRT_TEST2  1
#define CRT_NUCO1  2
#define CRT_NUCO2  3
#define	CRT_TEXT   4
#define CRT_INV    5
#define	CRT_UP_ADD	0xFF


#define CRT_VGA_A1  0
#define CRT_VGA_B1  1
#define	CRT_VGA_B2	2
#define	CRT_VGA_BC1	3
#define	CRT_RSV		4
#define CRT_N       5

#define RED_MN  0
#define GRN_MN  1
#define BLU_MN  2
#define RED_2B  3
#define GRN_2B  4
#define BLUE_2B 5
#define COL_6B  6
#define GSC_4B  7

#define	COL_RED		0x03		/*	Red		0000_0011B	*/
#define	COL_GRN		0x0C		/*	Green	0000_1100B	*/
#define	COL_BLU		0x30		/*	Blue	0011_0000B	*/
#define	COL_YEL		0x0F		/*	Yellow	0000_1111B	*/
#define	COL_CYA		0x3C		/*	Cyan	0011_1100B	*/
#define	COL_MAG		0x33		/*	Magenta	0011_0011B	*/
#define	COL_WHI		0x3F		/*	White	0011_1111B	*/

#define CHGN_MODE   0


/* -------------------------------------------------------------------------
 [VGA_TEST]
 	64x64
 ---------------------------------------------------------------------------*/
#define H_DOT_N_VGA_A           64
#define	H_NUM_FRM_VGA_A			64
#define V_SYNC_START_VGA_A      66
#define V_SYNC_END_VGA_A        68
#define V_BLANK_VGA_A           ( V_SYNC_END_VGA_A + 68 )					// 68 +68 = 136
#define H_LINE_FRM_VGA_A        ( V_BLANK_VGA_A + H_NUM_FRM_VGA_A *6 )		// 136 + 64*6 = 522
#define H_LINE_END_VGA_A        524
#define H_LINE_FRM_VGA_NUCO     ( V_BLANK_VGA_A + H_NUM_FRM_VGA_A *4 )		// 136 + 64*5 = 456

/*==========================================================================*/
/*  RAM PUBLIC                                                              */
/*==========================================================================*/
CRT_EXT UB  UB_ModeColor;

/*==========================================================================*/
/*	C++                                                  	               */
/*==========================================================================*/
class CCRT				//CCRTはインスタンス化されていないのでは？
{
public:
    CCRT();    			//コンストラクタの宣言 名前はクラスと同じになる。
						//ここでは引数無し
    void Ini();
    void ChangeMode( UB );
	
    PROGMEM static const UB TEST1_data[ 64*3 ];
    PROGMEM static const UB AyaNuco1[ 64 * 64 ];
    PROGMEM static const UB AyaNuco2[ 64 * 64 ];
	
private:

};

