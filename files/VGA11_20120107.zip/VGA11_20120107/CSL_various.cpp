/*****************************************************************************
    System Name : Arduino 2010
    File Name   : CSL_various.cpp
    Content     : 
    Version     : 0.0
    CPU board   : Arduino Duemilanove
    Compiler    : 
    History     :2010/03/17
*****************************************************************************/
/*----------------------------------------------------------------------------
;  Copyright (C) 2010 Masami Watanabe
;
;  This program is free software; you can redistribute it and/or modify it
;  under the terms of the GNU General Public License as published by the Free
;  Software Foundation; either version 3 of the License, or (at your option)
;  any later version.
;
;  This program is distributed in the hope that it will be useful, but
;  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
;  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
;  for more details.
;
;  You should have received a copy of the GNU General Public License along
;  with this program. If not, see <http://www.gnu.org/licenses/>.
;---------------------------------------------------------------------------*/
/*==========================================================================*/
/*  Includes                                                                */
/*==========================================================================*/
#include "SYSdef.h"
#include "CSLdef.h"
#include "INTdef.h"

/*==========================================================================*/
/*                                                                          */
/*==========================================================================*/

/*==========================================================================*/
/*  Program                                                                 */
/*==========================================================================*/
/*----------------------------------------------------------------------------
* Function : CRT
* Descr    : 
* Inputs   : 
* Outputs  : 
* Return   : 
*---------------------------------------------------------------------------*/
CCSL::CCSL()
{
    Ini();
}

void CCSL::Ini()
{
    clear();
}
    
void CCSL::clear()
{
    int i;
    for( i = 0; i < COL_MAX*ROW_MAX; i++ ){
        vram_data[i] = 0x20;
    }
}

void CCSL::print( const char *s, int line, int col )
{
    /* coming soon  */
}


void CCSL::cursor(int line, int col) {

    /* comoing soon */
}      
 

